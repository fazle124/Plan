// Firebase setup for this portfolio.
// 1) Create a Firebase project at https://console.firebase.google.com/
// 2) Add a Web App and paste its config below.
// 3) Enable Firestore Database and deploy the rules in firestore.rules.
// The Firebase web config is intended to be public; secure data with Firestore Rules and App Check.
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "PASTE_YOUR_FIREBASE_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_FIREBASE_APP_ID"
};

const configured = !Object.values(firebaseConfig).some(value =>
  String(value).startsWith("PASTE_") || String(value).startsWith("YOUR_")
);

let db = null;
if (configured) {
  const app = initializeApp(firebaseConfig);
  db = getFirestore(app);
}
export { db, configured };
